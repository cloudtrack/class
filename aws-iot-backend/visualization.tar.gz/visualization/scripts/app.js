'use strict';
angular.module('IoTHackDayDashboard', 
	[
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'config'
	]).
    config(['$routeProvider', function($routeProvider) {
        $routeProvider.
        when('/dashboard', {
            templateUrl: 'views/partials/sensors.html',
            controller: 'SensorsCtrl'
        }).
        when('/dashboard/:deviceID', {
            templateUrl: 'views/partials/sensors.html',
            controller: 'SensorsCtrl'
        }).                                
        when('/teams/:teamID', {
            templateUrl: 'views/partials/team_dashboard.html',
            controller: 'TeamDashboardCtrl'
        }).                                
        when('/status', {
            templateUrl: 'views/partials/status.html',
            controller: 'StatusCtrl'
        }).                                
        when('/leaderboard', {
            templateUrl: 'views/partials/leaderboard.html',
            controller: 'LeaderboardCtrl'
        }).
        when('/setup', {
            templateUrl: 'views/partials/setup.html',
            controller: 'SetupCtrl'
        }).                        
        otherwise({
            redirectTo: '/leaderboard'
        });
    }]);


