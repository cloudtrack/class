angular.module('IoTHackDayDashboard')
	.directive('navBar', function($window, $log, $rootScope, ENV) {
		
		return {
			restrict: 'EA',
			scope: {active: '='},
			templateUrl: 'views/partials/navigation.html',
			link: function(scope, element, attrs) {
				$log.debug(scope);
				$('#' + scope.active).addClass('active');
			}
		}
	});