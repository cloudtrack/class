angular.module('IoTHackDayDashboard')
	.directive('d3Bar', function($window, $log) {
		return {
			restrict: 'EA',
			scope: {data: '='},
			link: function(scope, element, attrs) {
				var margin = parseInt(attrs.margin) || 20;
				var barHeight = parseInt(attrs.barHeight) || 320;
				var barPadding = parseInt(attrs.barPadding) || 10;
				var svg = d3.select(element[0])
				.append('svg')
				.style('width', '100%')
				.style('height', '1250px');				

                // Browser onresize event
                $window.onresize = function() {
                	scope.$apply();
                };

                // Watch for resize event
                scope.$watch(function() {
                	return angular.element($window)[0].innerWidth;
                }, function() {
                	if (scope.data){
                		scope.render(getSeriesData(scope.data));
                	}
                });

                scope.$watch('data', function(){
                	if (scope.data){
                		scope.render(getSeriesData(scope.data));
                	}
                });

                scope.render = function(data) {
                	nv.addGraph(function() {
                		var chart = nv.models.multiBarHorizontalChart()
                		.x(function(d) { return d.device_id })
                		.y(function(d) { return d.count })
                		.margin({top: 30, right: 20, bottom: 50, left: 80})
                        .showValues(false)           //Show bar value next to each bar.
                        .tooltips(false)             //Show tooltips on hover.
                        .transitionDuration(350)
                        .barColor(function(d){
                        	var color = d.count > 10 ? 'green' : 'yellow';
                        	if (d.count == 0) {
                        		color = 'red';
                        	}
                        	return nv.utils.getColor(color);
                        })
                        .showControls(false);        //Allow user to switch between "Grouped" and "Stacked" mode.

                        chart.yAxis
                        .tickFormat(d3.format(',.0f'));

                        svg.datum(data)
                        .call(chart);

                        nv.utils.windowResize(chart.update);

                        return chart;
                    });
                };


                var getSeriesData = function(data) {
                	return [
                	{
                		key: '# of Received Events',
                		values: data
                	}
                	];
                };


            }
        };
    });
