angular.module('IoTHackDayDashboard')
	.directive('d3Line', function($rootScope, $window, $log) {
		return {
			restrict: 'EA',
			scope: {data: '='},
			link: function(scope, element, attrs) {
				var margin = parseInt(attrs.margin) || 20;
				var barHeight = parseInt(attrs.barHeight) || 320;
				var barPadding = parseInt(attrs.barPadding) || 10;
				var svg = d3.select(element[0])
				.append('svg')
				.style('width', '100%')
				.style('height', '450px');				


                $rootScope.$on('update', function(){
                    if (scope.data){
                        scope.render(getSeriesData(scope.data));
                    }
                });



                scope.render = function(data) {
                	nv.addGraph(function() {
                		var chart = nv.models.lineChart()
                		.x(function(d) { return d.time })
                		.y(function(d) { return d.value })
                		.margin({top: 30, right: 30, bottom: 50, left: 50})
                        .tooltips(false)             //Show tooltips on hover.
                        .transitionDuration(350);

                        chart.yAxis
                        .tickFormat(d3.format(',.0f'));

                        chart.xAxis
                        .tickFormat(function(d){return d3.time.format('%d-%b %H:%M:%S')(parseTimestamp(d));});
                        //.tickFormat(function(d){return d3.time.format('%d-%b %H:%M:%S')(new Date(d));});


                        svg.datum(data)
                        .call(chart);

                        nv.utils.windowResize(chart.update);

                        return chart;
                    });
                };

                var parseTimestamp = function(time){
                    var timestamp = time.toString();
                    if (timestamp.charAt(0) == 2){
                        var year = timestamp.substring(0, 4);
                        var month = timestamp.substring(4, 6);
                        var day = timestamp.substring(6, 8);
                        var hour = timestamp.substring(8, 10);
                        var min = timestamp.substring(10, 12);
                        var sec = timestamp.substring(12, 14);
                        return new Date(year, month - 1, day, hour, min, sec);
                    } else {
                        return new Date(timestamp);
                    }
                }

                var getSeriesData = function(data) {
                	var seriesData = [];
                	for (var key in data) {
                		if (key === 'name') continue;
                		seriesData.push({
                			key: key,
                			values: data[key]
                		});
                	}
                    $log.debug(seriesData);
                	return seriesData;
                };


            }
        };
    });
