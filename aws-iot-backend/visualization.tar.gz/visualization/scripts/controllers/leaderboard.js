'use strict';
/**
 * @ngdoc function
 * @name IoTHackDayDashboard.controller:LeaderboardCtrl
 * @description
 * # LeaderboardCtrl
 * Controller of the IoTHackDayDashboard that handles the error dialog view.
 */
angular.module('IoTHackDayDashboard').
	controller('LeaderboardCtrl', function ($log, $scope, $interval, $location, $routeParams, $timeout, ENV, LeaderboardReader) {
        
        $scope.active = 'leaderboard';
        var reader = new LeaderboardReader(50, 3000);

        reader.on('updated', function(data){
            $scope.data = data;
            $scope.$apply();
        });

        reader.start();

        if ($routeParams.autobrowseTimeout){
        	$timeout(function(){
        		$scope.$apply(function(){
        			$location.url('/status?autobrowseTimeout=' + $routeParams.autobrowseTimeout);
        		});

            }, $routeParams.autobrowseTimeout);
        }

        /*
        * Handler called when the view is destroyed. 
        */
        $scope.$on('$destroy', function(){
            reader.stop();
        });

	});

