'use strict';
/**
 * @ngdoc function
 * @name IoTHackDayDashboard.controller:TeamDashboardCtrl
 * @description
 * # TeamDashboardCtrl
 * Controller of the IoTHackDayDashboard that handles the error dialog view.
 */
angular.module('IoTHackDayDashboard').
	controller('TeamDashboardCtrl', function ($log, $scope, $interval, $location, $routeParams, $timeout, ENV, TeamTableReader) {
        var reader = new TeamTableReader($routeParams.teamID, 3000);
        $scope.teamID = $routeParams.teamID;

        reader.on('updated', function(type, data){
            $log.debug('Received data');
            $log.debug(data);
            $scope.deviceType = type;
            $scope.sensors = data;
            $scope.$apply();
            $scope.$emit('update');
        });

        reader.init();

        reader.start();

        /*
        * Handler called when the view is destroyed. 
        */
        $scope.$on('$destroy', function(){
            reader.stop();
        });

	});

