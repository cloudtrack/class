'use strict';
/**
 * @ngdoc function
 * @name IoTHackDayDashboard.controller:SensorsCtrl
 * @description
 * # SensorsCtrl
 * Controller of the IoTHackDayDashboard that handles the error dialog view.
 */
angular.module('IoTHackDayDashboard').
	controller('SensorsCtrl', function ($log, $scope, $route, $routeParams, $location, $timeout, ENV, DynamoDBReader, LeaderboardReader, Graph) {
		$scope.active = 'dashboard';
		$scope.dataSource = 'Top 10 Participants';
		var graph;
		var nTeams = 10;
		if ($routeParams.top){
			nTeams = $routeParams.top;
		}

		var reader = new DynamoDBReader();

		reader.on('initialized', function(){
			$log.info('Instantiating a new graph');
			graph = new Graph();
			graph.init(reader.getDeviceIDList(), reader.getSeriesData());
		});

		reader.on('updated', function(){
			$log.debug('Updating the graph');
			graph.update();
		});

		var getDeviceIDList = function(callback){
			var deviceIDList = [];
			if ($routeParams.deviceID) {
				$scope.dataSource = $routeParams.deviceID;
				deviceIDList.push($routeParams.deviceID);
				callback(deviceIDList);
			} else {
				new LeaderboardReader(nTeams).loadData(function(data){
					for (var i in data){
						/*jshint camelcase: false */
						deviceIDList.push(data[i].device_id);
					}				
					callback(deviceIDList);	
				});
			}
		};

		getDeviceIDList(function(deviceIDList){
			reader.init(ENV.commonTable, deviceIDList, $routeParams.time, 3000, 3, 150);
			reader.start();
		});


		if ($routeParams.autobrowseTimeout){ // Autobrowse enabled
			$timeout(function(){
				$location.url('/leaderboard?autobrowseTimeout=' + $routeParams.autobrowseTimeout);
			}, $routeParams.autobrowseTimeout);
		} else { // Auto browse disabled. Reloads in 1 min to get the latest top 10
			$timeout(function(){
				$route.reload();
			}, 300000);
		}

        /*
        * Handler called when the view is destroyed. 
        */
        $scope.$on('$destroy', function(){
        	reader.stop();
        });  
    });

