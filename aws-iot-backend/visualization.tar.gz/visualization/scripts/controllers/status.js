'use strict';
/* global $ */
/**
 * @ngdoc function
 * @name IoTHackDayDashboard.controller:StatusCtrl
 * @description
 * # StatusCtrl
 * Controller of the IoTHackDayDashboard that handles the error dialog view.
 */
angular.module('IoTHackDayDashboard').
	controller('StatusCtrl', function ($log, $scope, $location, $routeParams, $timeout, $interval, ENV, LeaderboardReader) {
		$scope.active = 'status';
        var reader = new LeaderboardReader(50, 3000);

        reader.on('updated', function(data){
            renderData(data);
        });

        reader.start();

        if ($routeParams.autobrowseTimeout){
            $timeout(function(){
                $location.url('/dashboard?autobrowseTimeout=' + $routeParams.autobrowseTimeout);
            }, $routeParams.autobrowseTimeout);
        }

        /*
        * Handler called when the view is destroyed. 
        */
        $scope.$on('$destroy', function(){
            reader.stop();
        });


        var teamsPerColumn = 13;

        // Calculate the number of columns and generate the HTML.

        var columns = [
        $('#column1'),
        $('#column2'),
        $('#column3'),
        $('#column4')
        ];

        var teamTemplate = function(data, index) {

        	var html = '<div class="team" data-index="' + index + '">';

            // Stoplight
            html += '<div class="markerRed markerRedFilled"></div>';
            html += '<div class="markerYellow ' + (data.count > 0  ? 'markerYellowFilled' : '') + '"></div>';
            html += '<div class="markerGreen ' + (data.count > 10 ? 'markerGreenFilled' : '') + '"></div>';
            // Rank and Name
            /*jshint camelcase: false */
            html += '<p class="team-name"><span class="rank">' + (index+1) + '.</span> <a href="/#/teams/' + data.device_id + '">' +  data.device_id + '</a></p>';

            html += '</div>';

            return html;
        };

        var renderData = function(data) {

        	var i, j, target;

        	for (i=0; i<columns.length; i++) {
        		columns[i].empty();
        	}

        	for (i=0; i<data.length; i++) {

        		target = 0;
        		j = i+1;

        		while(j > teamsPerColumn) {
        			j -= teamsPerColumn;
        			target++;
        		}

        		if (columns.length >= target - 1) {
        			columns[target].append(teamTemplate(data[i], i));
        		}

        	}

        };

	});

