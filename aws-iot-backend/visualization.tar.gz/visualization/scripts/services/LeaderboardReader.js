'use strict';
/**
 * @ngdoc function
 * @name IoTHackDayDashboard.service:LeaderboardReader
 * @description
 * # LeaderboardReader
 */
angular.module('IoTHackDayDashboard').
    service('LeaderboardReader', function ($log, $interval, AWS, ENV){
        var LeaderboardReader = function(_nTeams, _updateInteraval){
        	var nTeams = _nTeams;
        	var updateInterval = _updateInteraval;
        	var callbacks = {};
        	var timerCancel;

            this.init = function() {
                
            };

        	this.on = function(event, callback){
                callbacks[event] = callback;
            };

        	this.start = function() {
        		var reader = this;
                AWS.useAccount(true, function() { console.log("Switched to Common Account"); });
                this.loadData(function(data){
                	if (callbacks.updated){
                		callbacks.updated(data);
                	}
                    timerCancel = $interval(function(){
                        reader.loadData.call(reader, callbacks.updated);
                    }, updateInterval);
                });
            };

            this.stop = function() {
                if (timerCancel) {
                    $interval.cancel(timerCancel);
                    timerCancel = null;
                }
            };

            this.loadData = function(callback) {
            	var params = {
            		TableName: ENV.leaderboardTable,
            		KeyConditions: [
            		AWS.dynamoDB.Condition('event_name', 'EQ', 'iotHackDay')
            		],
            		IndexName: 'event_name-count-index',
            		Limit: nTeams,
            		ScanIndexForward: false
            	};
            	AWS.dynamoDB.query(params, function(err, data){
            		if (!err) {
            			console.log('Received leaderboard data');
            			addTeamsWithEmptyCounts(data.Items);
            			callback(data.Items);
            		} else {
            			console.error(err);
            		}
            	});
            };

            var addTeamsWithEmptyCounts = function(data){
            	
                return;
                
                if (data.length >= nTeams){
            		return;
            	}
                
            	var tmpMap = {};
                for (var i = 1; i <= nTeams; i++){ // Creates a map of all teams with 0 count
                	var teamId = 'team' + i;
                    /*jshint camelcase: false */
                	var d = {'device_id': teamId, count: 0};
                	tmpMap[teamId] = d;
                }
                for (var j in data){ // Removes teams who have data
                	var deviceId = data[j].device_id;
                	if (tmpMap[deviceId]){
                		delete tmpMap[deviceId];
                	} else {

                    }
                }
                for (var id in tmpMap){ // Concatinates teams who don't have data yet
                	data.push(tmpMap[id]);
                }
            };
        };
        return LeaderboardReader;

    });