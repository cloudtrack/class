'use strict';
/**
 * @ngdoc function
 * @name IoTHackDayDashboard.service:DynamoDBReader
 * @description
 * # DynamoDBReader
 */
angular.module('IoTHackDayDashboard').
    service('DynamoDBReader', function ($log, $interval, AWS){
        var DynamoDBReader = function(){
            var now;
            var updatesData;
            var tableName;
            var updateInterval;
            var nSlotsToUpdate;
            var maxPlots;
            var callbacks = {};
            var seriesData;
            var devices;
            var timerCancel;
            var deviceIDList;

            this.init = function(_tableName, _deviceIDList, _baseTime, _updateInterval, _nSlotsToUpdate, _maxPlots){
                
                tableName = _tableName;
                if (_baseTime){
                    console.log('Basetime is set to ' + _baseTime);
                    now = _baseTime;
                    updatesData = false;
                } else {
                    now = new Date().getTime();
                    updatesData = true;
                }
                updateInterval = _updateInterval;
                nSlotsToUpdate = _nSlotsToUpdate;
                maxPlots = _maxPlots;
                deviceIDList = _deviceIDList;

                seriesData = [];
                devices = {};
                for (var i in _deviceIDList) {
                    seriesData.push([]);
                    devices[_deviceIDList[i]] = {
                        updatedAt: 0,
                        data: seriesData[i]
                    };
                }

            };

            this.getDeviceIDList = function(){
                return deviceIDList;
            };

            this.getSeriesData = function(){
                return seriesData;
            };

            this.on = function(event, callback){
                callbacks[event] = callback;
            };

            this.start = function() {
                AWS.useAccount(true, function() { console.log("Switched to Common Account"); });
                loadInitialData(function(){
                    var callback = callbacks.initialized;
                    if (callback) {
                        callback();
                    }
                    if (updatesData){ 
                        var reader = this;
                        timerCancel = $interval(function(){
                            updateData.call(reader, callbacks.updated);
                        }, updateInterval);
                    }
                });
            };

            this.stop = function() {
                if (timerCancel) {
                    $interval.cancel(timerCancel);
                    timerCancel = null;
                }
            };

            var loadInitialData = function(callback) {
                $log.debug('Loading initial data');
                var updateGraph = function(id, events){
                    for (var i = maxPlots - 1; i >= 0; i--){
                        var slot = now - i * updateInterval;
                        devices[id].data.push({
                            x: slot,
                            y: countEvents(events, slot - updateInterval, slot)
                        });
                    }
                    devices[id].updatedAt = now;

                    if (allDevicesDataUpToDate()){
                        now += updateInterval;
                        callback();
                    }
                };

                for (var id in devices) { 
                    getData(id, now - updateInterval * maxPlots, updateGraph);
                }
            };

            var updateData = function(callback){
                var updateGraph = function(id, events){
                    for (var i = nSlotsToUpdate - 1; i >= 0; i--) {
                        var slot = now - i * updateInterval;
                        var plot = {
                            x: slot,
                            y: countEvents(events, slot - updateInterval, slot)
                        };
                        if (i > 0){
                            devices[id].data[maxPlots - i] = plot;
                        } else {
                            devices[id].data.push(plot);
                            devices[id].data.shift();
                        }
                    }

                    devices[id].updatedAt = now;
                    if (allDevicesDataUpToDate()){
                        now += updateInterval;
                        callback();
                    }
                };
                
                for (var id in devices) {
                    getData(id, now - updateInterval * nSlotsToUpdate, updateGraph);
                }
            };

            var getData = function(deviceID, time, callback) {

                if (devices[deviceID].timestampType === 'ISO'){
                    $log.debug('We query with ISO timestamp');
                    time = convertEpochToISO(time);
                }
                var params = { 
                    TableName: tableName,
                    KeyConditions: [
                    AWS.dynamoDB.Condition('device_id', 'EQ', deviceID),
                    AWS.dynamoDB.Condition('time', 'GE', time)
                    ],
                    Limit: 500,
                    ScanIndexForward: true
                };
                $log.debug(params);
                AWS.dynamoDB.query(params, function(error, data){
                    if (!error) {
                        if (data.Count > 0){
                            $log.debug(data.Count + ' data points received from device ' + deviceID);
                            if (isISOTimestamp(data.Items[0].time)){
                                if (!devices[deviceID].timestampType){
                                    $log.debug('Setting timestamp type to ISO');
                                    devices[deviceID].timestampType = 'ISO';
                                    getData(deviceID, time, callback);
                                } else {
                                    $log.debug('Converting timestamp from ISO to Epoch');
                                    convertTimestampInItems(data.Items);
                                    $log.debug(data.Items);
                                    callback(deviceID, data.Items);
                                }
                            } else {
                                if (!devices[deviceID].timestampType){
                                    $log.debug('Setting timestamp type to Epoch');
                                    devices[deviceID].timestampType = 'Epoch';
                                }
                                callback(deviceID, data.Items);
                            }
                        } else {
                            $log.info('No data for the device.');
                            callback(deviceID, data.Items);                            
                        }
                    } else {
                        $log.error(error);
                    }
                });
            };

            var convertTimestampInItems = function(items){
                for (var i in items){
                    var item = items[i];
                    item.time = convertISOToEpoch(item.time);
                }
            };

            var isISOTimestamp = function(time){
                if(time){
                    return time.toString().charAt(0) === '2';
                } else {
                    return false;
                }
            };

            var convertISOToEpoch = function(time){
                var timestamp = time.toString();

                var date = new Date(0);
                date.setUTCFullYear(timestamp.substring(0, 4));
                date.setUTCMonth(timestamp.substring(4, 6) - 1);
                date.setUTCDate(timestamp.substring(6, 8));
                date.setUTCHours(timestamp.substring(8, 10));
                date.setUTCMinutes(timestamp.substring(10, 12));
                date.setUTCSeconds(timestamp.substring(12, 14));

                return date.getTime();
            };

            var convertEpochToISO = function(time){
                return parseInt(new Date(time).toISOString().split('.')[0].replace(/[:T-]/g, ''));
            };

            var countEvents = function(events, from, to) {
                var count = 0;
                var event = events.shift();
                while (event) {
                    var timestamp = parseTimestamp(event.time);
                    if (from <= timestamp && timestamp < to) {
                        count++;
                        event = events.shift();
                    } else {
                        events.unshift(event);
                        break;
                    }
                }
                return count;
            };
            var parseTimestamp = function(time){
                return parseInt(time);
            };

            var allDevicesDataUpToDate = function(){
                for (var id in devices) {
                    if (devices[id].updatedAt !== now) {
                        return false;
                    }
                }
                return true;
            };
        };

        return DynamoDBReader;	
    });
