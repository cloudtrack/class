'use strict';
/* global AWS, DynamoDB */
/**
 * @ngdoc function
 * @name IoTHackDayDashboard.service:AWS
 * @description
 * # AWS
 * Service of the IoTHackDayDashboard. It initializes AWS SDK with providing credentials
 * either from Cognito Identity service or environment variables as specified in ENV service.
 * It initializes a DynamoDB client instance. The instance is exposed as AWS.dynamoDB. 
 */
angular.module('IoTHackDayDashboard').
    service('AWS', function ($log, ENV){

        AWS.config.update({region: 'us-east-1'});

        var common = new AWS.CognitoIdentityCredentials({
            AccountId: ENV.commonAWSAccountId,
            IdentityPoolId: ENV.commonIdentityPoolId,
            RoleArn: ENV.commonUnauthRoleArn
        });

        var team = new AWS.CognitoIdentityCredentials({
            AccountId: ENV.awsAccountId,
            IdentityPoolId: ENV.identityPoolId,
            RoleArn: ENV.unauthRoleArn    
        });

        AWS.useAccount = function(isCommonAccount, callback) {
          
          if (isCommonAccount) {
            AWS.config.credentials = common;
          } else {
            AWS.config.credentials = team;
          }

          AWS.config.credentials.refresh(function() {
            // console.log(AWS.config);
          });
          
          AWS.dynamoDB = new DynamoDB(
            new AWS.DynamoDB({
                region: ENV.dynamoDBRegion,
                endpoint: ENV.dynamoDBEndpoint
          }));

          callback();

        };

        return AWS;

    });
