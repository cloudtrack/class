'use strict';
/**
 * @ngdoc function
 * @name IoTHackDayDashboard.service:TeamTableReader
 * @description
 * # TeamTableReader
 */
angular.module('IoTHackDayDashboard').
    service('TeamTableReader', function ($log, $interval, AWS, ENV){
        var TeamTableReader = function(_teamID, _updateInteraval){
        	var teamID = _teamID;
        	var updateInterval = _updateInteraval;
        	var callbacks = {};
        	var timerCancel;
        	var lastDataReceived;
        	var seriesData;
            

        	this.init = function() {
        		seriesData = {};
        	};

        	this.on = function(event, callback){
                callbacks[event] = callback;
            };

        	this.start = function() {
        		var reader = this;
                AWS.useAccount(false, function () { console.log('Switched to Team Account'); });
                this.loadData(function(deviceType, data){
                	if (callbacks.updated){
                		callbacks.updated(deviceType, data);
                	}
                    timerCancel = $interval(function(){
                        reader.loadData.call(reader, callbacks.updated);
                    }, updateInterval);
                });

            };

            this.stop = function() {
                if (timerCancel) {
                    $interval.cancel(timerCancel);
                    timerCancel = null;
                }
            };


            this.loadData = function(callback) {

                var params = {
                        TableName: ENV.teamTable,
                        KeyConditions: [
                        AWS.dynamoDB.Condition('device_id', 'EQ', teamID)
                        ],
                        Limit: 50,
                        ScanIndexForward: false
                    };

                    if (lastDataReceived) {
                        $log.debug('Getting data after ' + lastDataReceived);
                        params.KeyConditions.push(AWS.dynamoDB.Condition('time', 'GT', lastDataReceived));
                    }

                    AWS.dynamoDB.query(params, function(err, data){
                        if (!err) {
                            if (data.Items.length > 0 ) {
                                lastDataReceived = data.Items[0].time;
                                var deviceType = data.Items[0].device;
                                updateSeriesData(seriesData, data.Items);
                                $log.debug(seriesData);
                                callback(deviceType, seriesData);
                            } else {
                                $log.debug('No new data received');
                            }
                        } else {
                            console.error(err);
                        }
                    });
            };

            var updateSeriesData = function(seriesData, data) {
                for (var i in data) {
            		//var time = data[i].time;
                    //console.log(time);
                    appendSensorData(seriesData, "accelerometer", data[i].time, data[i].sensors);
                    //for (var j in data[i].sensors){
                        //var sensorData = JSON.parse(data[i].sensors);
                        //for (var accelerometer in sensorData){
                          
                        //}
                    //}
            	}
            };

            var appendSensorData = function(seriesData, key, time, value){
            	if (!seriesData[key]){
            		seriesData[key] = {name: key};
            	}
                if (typeof(value) === 'string'){
                    value = JSON.parse(value);
                }
            	if (typeof(value) === 'object'){
            		for (var subKey in value) {
            			if (!seriesData[key][subKey]){
            				seriesData[key][subKey] = [];
            			}
            			seriesData[key][subKey].push({time: time, value: value[subKey]});
            		}
            	} else {
            		if (!seriesData[key][key]){
            			seriesData[key][key] = [];
            		}
            		seriesData[key][key].push({time: time, value: value});
            	}
            };
        };
        return TeamTableReader;

    });