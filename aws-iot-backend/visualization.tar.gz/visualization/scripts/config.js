"use strict";

angular.module('config', [])

.constant('ENV', {
	name: 'production',
	commonAWSAccountId: '555818481905',
	awsAccountId: '[YOUR AWS ACCOUNT ID]',
	identityPoolId: '[YOUR IDENTITY POOL ID]',
	unauthRoleArn: '[YOUR UNAUTHENTICATED ROLE ARN]',
	commonIdentityPoolId: 'us-east-1:7035f3db-c7f7-4650-a076-2a5bb0c790e5',
	commonUnauthRoleArn: 'arn:aws:iam::555818481905:role/connected-maraca/connected-maraca-CognitoUnauthRole-D367NBZ1M10S',
	useCognitoIdentity: true,
	userId: 'localUser',
	dynamoDBRegion: 'us-west-2',
	dynamoDBEndpoint: 'https://dynamodb.us-west-2.amazonaws.com/',
	commonTable: 'connected-maraca-CommonDeviceTable-11DU5UOK3RUA5',
	leaderboardTable: 'connected-maraca-LeaderboardTable-FQKYUCP836EO',
	teamTable: '[YOUR_DEVICE_TABLE]',
	teamName: '[YOUR_TEAM_NAME]',
})

;